#ifndef UTILITIES_H
#define UTILITIES_H

#include <iostream>

//global functions that are used in multiple files

using namespace std;

//converts string to lowercase
string toLowerCase(string);

void clearInput();

#endif